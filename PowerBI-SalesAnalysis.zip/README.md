
# 📊 Power BI Sales & Profit Analysis Dashboard

This project analyzes fictional retail sales data to uncover business insights. It uses Power BI to visualize metrics like sales trends, customer behavior, and profit distribution across regions.

## 🛠 Tools Used
- Power BI Desktop
- SQL Server (for data prep)
- DAX

## 📂 Contents
- `/Dashboard`: .pbix file with interactive report
- `/Data`: Sample CSV used to simulate retail sales
- `/SQL`: Table creation and data preparation scripts
- `/DAX`: Measures used for KPIs
- `/Screenshots`: Report visuals for quick preview

## 📌 Key Metrics
- Total Sales, Profit, Profit Margin
- Region-wise and Category-wise Sales
- Monthly & Yearly Growth
- RFM Segmentation
- Customer Lifetime Value (CLTV)

## 📷 Preview

![Dashboard Preview](Screenshots/dashboard_preview.png)

---

Feel free to clone or fork this repo and reuse it for learning or job interviews.
